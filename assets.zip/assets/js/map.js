
    mapboxgl.accessToken = 'pk.eyJ1IjoiYWxyaWEtZmFyZ29zZTEiLCJhIjoiY2tvbGllN2F0MGtrMTJ2bzZqcXl2aGd2MCJ9.a0E2M-6svFBfJlG9h_bh0g';
var  map
function mapinit(){
   map = new mapboxgl.Map({
  container: 'map',
  style: 'mapbox://styles/mapbox/streets-v11'
  });

  feedData() }



  function feedData() {
      fetch('https://photobucketapp-e79e2-default-rtdb.firebaseio.com/feed.json')
      .then((response) => {
          return response.json()
      })
      .then((data)=>{
         console.log(data) 
        var ids = Object.keys(data)

          for (i=0;i<ids.length;i++){
              // create the popup
var popup = new mapboxgl.Popup({ offset: 25 }).setHTML(
    '<p> Requirements : ' + data[ids[i]].status + ' </p> <img src=' + data[ids[i]].image + ' /> <p> Email : ' + data[ids[i]].email + ' </p>'
    );
     
    // create DOM element for the marker
    var el = document.createElement('div');
    el.id = 'marker';
     
    // create the marker
    new mapboxgl.Marker()
    .setLngLat([data[ids[i]].location.longitude, data[ids[i]].location.latitude])
    .setPopup(popup) // sets a popup on this marker
    .addTo(map);
          }
      })
  }
