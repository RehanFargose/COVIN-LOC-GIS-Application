# Basic GIS application
 A webapp and website to which you can upload photos with your location and keep track of them
